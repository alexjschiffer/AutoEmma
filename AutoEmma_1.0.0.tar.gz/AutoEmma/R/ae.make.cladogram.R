##################################################
#   Function Name  : Make Cladogram              #
#   Program Author : Alex Schiffer               #
#   Last Updated   : June 22, 2018               #
#                                                #
#   D'Amato Lab, Boston Children's Hospital      #
##################################################

ae.make.cladogram <- function(ginput, pinput) {
  # Check if required packages are installed and load them
  ae.check.required()

  # Import phenotype information
  pheno_data <- ae.import(pinput)

  # Extract strain names
  if (!is.null(pheno_data)){
    colnames(pheno_data) <- toupper(colnames(pheno_data))
    strains_table <- pheno_data %>%
      dplyr::select("STRAIN") %>%
      dplyr::distinct()
    strains_vector <- strains_table[["STRAIN"]]
  }

  # Import genotype information
  snp_table <- ae.import(ginput)

  # Create SNP matrix
  if (!is.null(snp_table)) {
    snp_data <- snp_table %>%
      dplyr::select(one_of(strains_vector)) %>%
      data.matrix() %>%
      t()
  }

  # Generate tree based on gene distance
  stree <- snp_data %>%
    dist.gene(method = "pairwise") %>%
    nj()

  # For Future Development
  #if (color) {
    # Create categories
    #pheno_data <- dplyr::mutate(pheno_data, cat = 1)
    #strain_data$cat["Average" < 1] <- 2
    #strain_data$cat[Average >= 1] <- 2
    #pheno_cats <- strain_data[["cat"]]

    # Create color spectrum
    #cs <- colorRamps::blue2red(length(pheno_cats))

    # Map color spectrum onto phenotype data
    # colors_vecs <- c()
    #for (x in c(1:length(stree$tip.label))) {
    #  category <- pheno_cats[x]
    #  colors_vecs[x] <- colors[category]
    #}
  #}

  # Plot and save tree
  (ggtree(stree, layout = "circular", branch.length = "none")
    + ggtitle("Cladogram")
    + theme(plot.title = element_text(hjust = 0.5), plot.margin = unit(c(0.5,0.25,0.25,0.25),"cm"),
            axis.title = element_text(size = 14))
    + geom_tiplab(size = 2.75, aes(angle=angle))
    + ggsave(filename = (paste("results/", tools::file_path_sans_ext(pinput), "-cladogram.png", sep = "")), plot = last_plot(),
           device = "png", width = 7.5, height = 5.0, dpi = 300, units = "in"))
}
