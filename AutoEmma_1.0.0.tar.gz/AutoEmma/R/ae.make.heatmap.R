##################################################
#   Function Name  : Run AutoEmma                #
#   Program Author : Alex Schiffer               #
#   Last Updated   : June 22, 2018               #
#                                                #
#   D'Amato Lab, Boston Children's Hospital      #
##################################################

ae.heatmap<- function(input, labelsize = 5) {
  # Check if required packages are installed and load them
  ae.check.required()

  # Load in genotype kinship matrix
  m <- readr::read_tsv(input, col_names = TRUE)
  m <- m[,4:dim(m)[2]]
  m <- data.matrix(m)

  strains = colnames(m)

  k <- emma.kinship(m)
  colnames(k) <- strains
  rownames(k) <- strains

  suppressMessages(
    (ggcorrplot(k) + ggtitle("Kinship Matix")
    + coord_fixed(ratio = 1)
    + scale_fill_continuous(low = "white", high = "blue",name = "Relatedness\n",limits= c(0,1))
    + theme(plot.title = element_text(hjust = 0.5),
            axis.text.x = element_text(size = labelsize),
            axis.text.y = element_text(size = labelsize),
            legend.title = element_text(size =12),
            legend.text = element_text(size = labelsize),
            legend.margin = margin(t = 1, r = 0, b = 0, l = 0, unit = "pt"),
            legend.key.height=unit(2,"line")
            )
    + ggsave(filename = (paste("results/", tools::file_path_sans_ext(input), "-heatmap.png", sep = "")), plot = last_plot(),
             device = "png", width = 7.5, height = 5.0, dpi = 300, units = "in"))
  )
}
