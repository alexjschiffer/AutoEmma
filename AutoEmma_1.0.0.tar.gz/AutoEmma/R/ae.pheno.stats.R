##################################################
#   Function Name  : Phenotype Stats             #
#   Program Author : Alex Schiffer               #
#   Last Updated   : July 5, 2018                #
#                                                #
#   D'Amato Lab, Boston Children's Hospital      #
##################################################

ae.pheno.stats <- function(infile){

  # Check if required packages are installed and load them
  ae.check.required()

  # Read in dataset and vectorize information
  data <- ae.import(infile)
  colnames(data) <- toupper(colnames(data))
  groups <- dplyr::distinct(dplyr::select(data, "STRAIN"))[["STRAIN"]]
  values <- data[["VALUE"]]

  # Initialize vectors for each statistic to be calculated
  count = c()
  avg = c()
  sd = c()
  mad = c()
  counter <- 1

  # Calculate Average, standard deviation, and median absolute deviation for each strain
  for (i in seq_along(groups)) {
    temp <- dplyr::filter(data, STRAIN == groups[i])
    count[counter] <- nrow(temp)
    avg[counter] <- mean(temp$VALUE)
    sd[counter] <- sd(temp$VALUE)
    mad[counter] <- mad(temp$VALUE)
    counter <- counter + 1
  }

  # Assemble new data set and save to working directory
  new_data <- dplyr::data_frame(Count = count, Strain = groups, Average = avg, Stdev = sd, Mad = mad)
  write_tsv(new_data, "averages_stdevs.txt", append = FALSE, col_names = TRUE)

  # Create bar graph of average phenotype per strain
  arranged <- arrange(new_data, Average)
  order <- arranged[["Strain"]]
  (ggplot(arranged, aes(x = Strain, y = Average, width = 1))
    + geom_bar(stat = "identity", color = "blue",fill = "gray30")
    + theme_minimal()
    + theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
            panel.grid.minor = element_blank()
            )
    + scale_x_discrete(limits = order)
    + ggsave(filename = (paste("results/", "testname", "-averages.png", sep = "")), plot = last_plot(),
             device = "png", width = 7.5, height = 5.0, dpi = 300, units = "in")
  )

  # Create histogram of all values of phenotype
  (ggplot(data, aes(x = data$VALUE))
    + geom_histogram(color = "blue", fill = "gray30", bins = 20)
    + labs(x = "Phenotype Values", y = "Count")
    + theme_minimal()
    + ggsave(filename = (paste("results/", tools::file_path_sans_ext(infile), "-histogram.png", sep = "")), plot = last_plot(),
             device = "png", width = 7.5, height = 5.0, dpi = 300, units = "in")
  )

}
